package it.prova.negoziopcroma.model;

public class SchedaMadre extends Prodotto{

	public SchedaMadre(String id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

	

}
