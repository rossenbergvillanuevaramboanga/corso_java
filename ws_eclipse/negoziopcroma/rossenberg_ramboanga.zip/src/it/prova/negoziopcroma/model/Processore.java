package it.prova.negoziopcroma.model;

public class Processore extends Prodotto{

	public Processore(String id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

	

}
